-- Beast Games: Supabase setup (already applied to the "Beast Games BSA" project).
-- Only run this on a NEW, EMPTY project. It drops regs/profiles/admins first.

drop table if exists public.regs cascade;
drop table if exists public.profiles cascade;
drop table if exists public.admins cascade;

create table public.admins (uid uuid primary key references auth.users(id) on delete cascade);

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  phone text not null, name text not null, roll text, course text,
  wt numeric, ht numeric, ch numeric, ts text, st text, col text, cat text, lv text,
  sc text, scx text, scimg text, father text, dob date, gender text,
  address text, city text, emerg text, idp text, photo text,
  aadhaar4 text check (aadhaar4 is null or aadhaar4 ~ '^[0-9]{4}$'),
  consent_at timestamptz, created_at timestamptz not null default now()
);

create table public.regs (
  id text primary key,
  uid uuid not null references public.profiles(id) on delete cascade,
  cat text not null check (cat in ('Athletes','Team')),
  game text not null, age_cat text, position text,
  team text not null default '', captain text not null default '', coach text not null default '',
  fee integer not null default 0 check (fee >= 0),
  pay_img text not null default '',
  pay_status text not null default 'pending' check (pay_status in ('pending','verified','rejected')),
  created_at timestamptz not null default now(),
  constraint regs_id_fmt check (id ~ '^BG-[A-Z0-9]{5}$'),
  constraint regs_uid_game_uniq unique (uid, game)
);

create table if not exists public.settings (key text primary key, value text not null default '');
create table if not exists public.game_fees (game text primary key, fee integer not null default 0 check (fee >= 0));

insert into public.settings(key,value) values
 ('reg_open','2026-10-04T18:30:00Z'),('upi_id',''),('upi_name','Beast Games'),('venue','BSA College, Mathura')
on conflict (key) do nothing;
insert into public.game_fees(game,fee)
select g,0 from unnest(array['100m Track','200m Track','400m Track','Long Jump','Shot Put','Discus Throw','Javelin Throw','Other athletics','Football','Volleyball','Basketball','Cricket','Kabaddi','Tug of War','Other team game']) g
on conflict (game) do nothing;

create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = public as
$$ select exists (select 1 from public.admins where uid = auth.uid()) $$;

create or replace function public.regs_guard() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if public.is_admin() then return new; end if;
  if tg_op = 'INSERT' then
    new.uid := auth.uid();
    new.fee := coalesce((select fee from public.game_fees where game = new.game), 0);
    new.pay_status := case when new.fee = 0 then 'verified' else 'pending' end;
    if new.fee > 0 and (new.pay_img is null or new.pay_img not like auth.uid()::text || '/%') then
      raise exception 'payment screenshot required'; end if;
  else
    if new.id <> old.id or new.uid <> old.uid or new.game <> old.game or new.cat <> old.cat
       or new.fee is distinct from old.fee or new.pay_status <> old.pay_status then
      raise exception 'not allowed'; end if;
    if new.pay_img is distinct from old.pay_img then
      if old.pay_status <> 'rejected' or new.pay_img not like auth.uid()::text || '/%' then
        raise exception 'not allowed'; end if;
      new.pay_status := 'pending';
    end if;
  end if;
  return new;
end $$;
create trigger regs_guard_trg before insert or update on public.regs
  for each row execute function public.regs_guard();

create or replace function public.profiles_guard() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'not allowed'; end if;
  return new;
end $$;
create trigger profiles_guard_trg before update on public.profiles
  for each row execute function public.profiles_guard();

revoke execute on function public.regs_guard() from public, anon, authenticated;
revoke execute on function public.profiles_guard() from public, anon, authenticated;
revoke execute on function public.is_admin() from public, anon;
grant execute on function public.is_admin() to authenticated;

alter table public.regs enable row level security;
alter table public.profiles enable row level security;
alter table public.admins enable row level security;
alter table public.settings enable row level security;
alter table public.game_fees enable row level security;

grant select on public.settings, public.game_fees to anon, authenticated;

create policy admins_self   on public.admins    for select to authenticated using (uid = auth.uid());
create policy settings_read on public.settings  for select to anon, authenticated using (true);
create policy settings_w    on public.settings  for all    to authenticated using (public.is_admin()) with check (public.is_admin());
create policy fees_read     on public.game_fees for select to anon, authenticated using (true);
create policy fees_w        on public.game_fees for all    to authenticated using (public.is_admin()) with check (public.is_admin());
create policy prof_sel on public.profiles for select to authenticated using (id = auth.uid() or public.is_admin());
create policy prof_ins on public.profiles for insert to authenticated with check (id = auth.uid());
create policy prof_upd on public.profiles for update to authenticated using (public.is_admin()) with check (public.is_admin());
create policy prof_del on public.profiles for delete to authenticated using (public.is_admin());
create policy regs_sel on public.regs for select to authenticated using (uid = auth.uid() or public.is_admin());
create policy regs_ins on public.regs for insert to authenticated with check (
  uid = auth.uid()
  and now() >= coalesce((select value::timestamptz from public.settings where key = 'reg_open'), now()));
create policy regs_upd on public.regs for update to authenticated
  using (uid = auth.uid() or public.is_admin()) with check (uid = auth.uid() or public.is_admin());
create policy regs_del on public.regs for delete to authenticated using (public.is_admin());

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('identity','identity',false,3145728,array['image/jpeg']),
       ('payments','payments',false,3145728,array['image/jpeg'])
on conflict (id) do update set public=false, file_size_limit=3145728, allowed_mime_types=array['image/jpeg'];

create policy bg_st_ins on storage.objects for insert to authenticated with check (
  bucket_id in ('identity','payments') and (storage.foldername(name))[1] = auth.uid()::text);
create policy bg_st_sel on storage.objects for select to authenticated using (
  bucket_id in ('identity','payments')
  and ((storage.foldername(name))[1] = auth.uid()::text or public.is_admin()));

-- Add an admin AFTER creating the user in Supabase > Authentication > Users:
-- insert into public.admins(uid) select id from auth.users where email = 'ADMIN_EMAIL_HERE';
